-- Admidio v4.3.6 (https://www.admidio.org)
-- Backup created on 10.04.2024 at 16:58:38

-- Database: admidio

-- User: Subhas Sing

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE `adm2_announcements` (
  `ann_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ann_cat_id` int(10) unsigned NOT NULL,
  `ann_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `ann_headline` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ann_description` text COLLATE utf8_unicode_ci,
  `ann_usr_id_create` int(10) unsigned DEFAULT NULL,
  `ann_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ann_usr_id_change` int(10) unsigned DEFAULT NULL,
  `ann_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ann_id`),
  UNIQUE KEY `adm2_idx_ann_uuid` (`ann_uuid`),
  KEY `adm2_fk_ann_cat` (`ann_cat_id`),
  KEY `adm2_fk_ann_usr_create` (`ann_usr_id_create`),
  KEY `adm2_fk_ann_usr_change` (`ann_usr_id_change`),
  CONSTRAINT `adm2_fk_ann_cat` FOREIGN KEY (`ann_cat_id`) REFERENCES `adm2_categories` (`cat_id`),
  CONSTRAINT `adm2_fk_ann_usr_change` FOREIGN KEY (`ann_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_ann_usr_create` FOREIGN KEY (`ann_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_auto_login` (
  `atl_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `atl_auto_login_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `atl_session_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `atl_org_id` int(10) unsigned NOT NULL,
  `atl_usr_id` int(10) unsigned NOT NULL,
  `atl_last_login` timestamp NULL DEFAULT NULL,
  `atl_number_invalid` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`atl_id`),
  KEY `adm2_fk_atl_usr` (`atl_usr_id`),
  KEY `adm2_fk_atl_org` (`atl_org_id`),
  CONSTRAINT `adm2_fk_atl_org` FOREIGN KEY (`atl_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_atl_usr` FOREIGN KEY (`atl_usr_id`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_categories` (
  `cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_org_id` int(10) unsigned DEFAULT NULL,
  `cat_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `cat_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `cat_name_intern` varchar(110) COLLATE utf8_unicode_ci NOT NULL,
  `cat_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cat_system` tinyint(1) NOT NULL DEFAULT '0',
  `cat_default` tinyint(1) NOT NULL DEFAULT '0',
  `cat_sequence` smallint(6) NOT NULL,
  `cat_usr_id_create` int(10) unsigned DEFAULT NULL,
  `cat_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat_usr_id_change` int(10) unsigned DEFAULT NULL,
  `cat_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `adm2_idx_cat_uuid` (`cat_uuid`),
  KEY `adm2_fk_cat_org` (`cat_org_id`),
  KEY `adm2_fk_cat_usr_create` (`cat_usr_id_create`),
  KEY `adm2_fk_cat_usr_change` (`cat_usr_id_change`),
  CONSTRAINT `adm2_fk_cat_org` FOREIGN KEY (`cat_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_cat_usr_change` FOREIGN KEY (`cat_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_cat_usr_create` FOREIGN KEY (`cat_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_category_report` (
  `crt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crt_org_id` int(10) unsigned DEFAULT NULL,
  `crt_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `crt_col_fields` text COLLATE utf8_unicode_ci,
  `crt_selection_role` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `crt_selection_cat` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `crt_number_col` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`crt_id`),
  KEY `adm2_fk_crt_org` (`crt_org_id`),
  CONSTRAINT `adm2_fk_crt_org` FOREIGN KEY (`crt_org_id`) REFERENCES `adm2_organizations` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_components` (
  `com_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `com_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `com_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `com_name_intern` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `com_version` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `com_beta` smallint(6) NOT NULL DEFAULT '0',
  `com_update_step` int(11) NOT NULL DEFAULT '0',
  `com_update_completed` tinyint(1) NOT NULL DEFAULT '1',
  `com_timestamp_installed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_events` (
  `dat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dat_cat_id` int(10) unsigned NOT NULL,
  `dat_rol_id` int(10) unsigned DEFAULT NULL,
  `dat_room_id` int(10) unsigned DEFAULT NULL,
  `dat_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `dat_begin` timestamp NULL DEFAULT NULL,
  `dat_end` timestamp NULL DEFAULT NULL,
  `dat_all_day` tinyint(1) NOT NULL DEFAULT '0',
  `dat_headline` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dat_description` text COLLATE utf8_unicode_ci,
  `dat_highlight` tinyint(1) NOT NULL DEFAULT '0',
  `dat_location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dat_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dat_deadline` timestamp NULL DEFAULT NULL,
  `dat_max_members` int(11) NOT NULL DEFAULT '0',
  `dat_usr_id_create` int(10) unsigned DEFAULT NULL,
  `dat_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dat_usr_id_change` int(10) unsigned DEFAULT NULL,
  `dat_timestamp_change` timestamp NULL DEFAULT NULL,
  `dat_allow_comments` tinyint(1) NOT NULL DEFAULT '0',
  `dat_additional_guests` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dat_id`),
  UNIQUE KEY `adm2_idx_dat_uuid` (`dat_uuid`),
  KEY `adm2_fk_dat_cat` (`dat_cat_id`),
  KEY `adm2_fk_dat_rol` (`dat_rol_id`),
  KEY `adm2_fk_dat_room` (`dat_room_id`),
  KEY `adm2_fk_dat_usr_create` (`dat_usr_id_create`),
  KEY `adm2_fk_dat_usr_change` (`dat_usr_id_change`),
  CONSTRAINT `adm2_fk_dat_cat` FOREIGN KEY (`dat_cat_id`) REFERENCES `adm2_categories` (`cat_id`),
  CONSTRAINT `adm2_fk_dat_rol` FOREIGN KEY (`dat_rol_id`) REFERENCES `adm2_roles` (`rol_id`),
  CONSTRAINT `adm2_fk_dat_room` FOREIGN KEY (`dat_room_id`) REFERENCES `adm2_rooms` (`room_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_dat_usr_change` FOREIGN KEY (`dat_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_dat_usr_create` FOREIGN KEY (`dat_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_files` (
  `fil_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fil_fol_id` int(10) unsigned NOT NULL,
  `fil_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `fil_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fil_description` text COLLATE utf8_unicode_ci,
  `fil_locked` tinyint(1) NOT NULL DEFAULT '0',
  `fil_counter` int(11) DEFAULT NULL,
  `fil_usr_id` int(10) unsigned DEFAULT NULL,
  `fil_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fil_id`),
  UNIQUE KEY `adm2_idx_fil_uuid` (`fil_uuid`),
  KEY `adm2_fk_fil_fol` (`fil_fol_id`),
  KEY `adm2_fk_fil_usr` (`fil_usr_id`),
  CONSTRAINT `adm2_fk_fil_fol` FOREIGN KEY (`fil_fol_id`) REFERENCES `adm2_folders` (`fol_id`),
  CONSTRAINT `adm2_fk_fil_usr` FOREIGN KEY (`fil_usr_id`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_folders` (
  `fol_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fol_org_id` int(10) unsigned NOT NULL,
  `fol_fol_id_parent` int(10) unsigned DEFAULT NULL,
  `fol_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `fol_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `fol_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fol_description` text COLLATE utf8_unicode_ci,
  `fol_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fol_locked` tinyint(1) NOT NULL DEFAULT '0',
  `fol_public` tinyint(1) NOT NULL DEFAULT '0',
  `fol_usr_id` int(10) unsigned DEFAULT NULL,
  `fol_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fol_id`),
  UNIQUE KEY `adm2_idx_fol_uuid` (`fol_uuid`),
  KEY `adm2_fk_fol_org` (`fol_org_id`),
  KEY `adm2_fk_fol_fol_parent` (`fol_fol_id_parent`),
  KEY `adm2_fk_fol_usr` (`fol_usr_id`),
  CONSTRAINT `adm2_fk_fol_fol_parent` FOREIGN KEY (`fol_fol_id_parent`) REFERENCES `adm2_folders` (`fol_id`),
  CONSTRAINT `adm2_fk_fol_org` FOREIGN KEY (`fol_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_fol_usr` FOREIGN KEY (`fol_usr_id`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_guestbook` (
  `gbo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gbo_org_id` int(10) unsigned NOT NULL,
  `gbo_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `gbo_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `gbo_text` text COLLATE utf8_unicode_ci NOT NULL,
  `gbo_email` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gbo_homepage` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gbo_ip_address` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `gbo_locked` tinyint(1) NOT NULL DEFAULT '0',
  `gbo_usr_id_create` int(10) unsigned DEFAULT NULL,
  `gbo_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gbo_usr_id_change` int(10) unsigned DEFAULT NULL,
  `gbo_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`gbo_id`),
  UNIQUE KEY `adm2_idx_gbo_uuid` (`gbo_uuid`),
  KEY `adm2_fk_gbo_org` (`gbo_org_id`),
  KEY `adm2_fk_gbo_usr_create` (`gbo_usr_id_create`),
  KEY `adm2_fk_gbo_usr_change` (`gbo_usr_id_change`),
  CONSTRAINT `adm2_fk_gbo_org` FOREIGN KEY (`gbo_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_gbo_usr_change` FOREIGN KEY (`gbo_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_gbo_usr_create` FOREIGN KEY (`gbo_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_guestbook_comments` (
  `gbc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gbc_gbo_id` int(10) unsigned NOT NULL,
  `gbc_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `gbc_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `gbc_text` text COLLATE utf8_unicode_ci NOT NULL,
  `gbc_email` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gbc_ip_address` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `gbc_locked` tinyint(1) NOT NULL DEFAULT '0',
  `gbc_usr_id_create` int(10) unsigned DEFAULT NULL,
  `gbc_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gbc_usr_id_change` int(10) unsigned DEFAULT NULL,
  `gbc_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`gbc_id`),
  UNIQUE KEY `adm2_idx_gbc_uuid` (`gbc_uuid`),
  KEY `adm2_fk_gbc_gbo` (`gbc_gbo_id`),
  KEY `adm2_fk_gbc_usr_create` (`gbc_usr_id_create`),
  KEY `adm2_fk_gbc_usr_change` (`gbc_usr_id_change`),
  CONSTRAINT `adm2_fk_gbc_gbo` FOREIGN KEY (`gbc_gbo_id`) REFERENCES `adm2_guestbook` (`gbo_id`),
  CONSTRAINT `adm2_fk_gbc_usr_change` FOREIGN KEY (`gbc_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_gbc_usr_create` FOREIGN KEY (`gbc_usr_id_create`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_ids` (
  `ids_usr_id` int(10) unsigned NOT NULL,
  `ids_reference_id` int(10) unsigned NOT NULL,
  KEY `adm2_fk_ids_usr_id` (`ids_usr_id`),
  CONSTRAINT `adm2_fk_ids_usr_id` FOREIGN KEY (`ids_usr_id`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_links` (
  `lnk_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lnk_cat_id` int(10) unsigned NOT NULL,
  `lnk_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `lnk_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lnk_description` text COLLATE utf8_unicode_ci,
  `lnk_url` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `lnk_counter` int(11) NOT NULL DEFAULT '0',
  `lnk_usr_id_create` int(10) unsigned DEFAULT NULL,
  `lnk_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lnk_usr_id_change` int(10) unsigned DEFAULT NULL,
  `lnk_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`lnk_id`),
  UNIQUE KEY `adm2_idx_lnk_uuid` (`lnk_uuid`),
  KEY `adm2_fk_lnk_cat` (`lnk_cat_id`),
  KEY `adm2_fk_lnk_usr_create` (`lnk_usr_id_create`),
  KEY `adm2_fk_lnk_usr_change` (`lnk_usr_id_change`),
  CONSTRAINT `adm2_fk_lnk_cat` FOREIGN KEY (`lnk_cat_id`) REFERENCES `adm2_categories` (`cat_id`),
  CONSTRAINT `adm2_fk_lnk_usr_change` FOREIGN KEY (`lnk_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_lnk_usr_create` FOREIGN KEY (`lnk_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_list_columns` (
  `lsc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lsc_lst_id` int(10) unsigned NOT NULL,
  `lsc_number` smallint(6) NOT NULL,
  `lsc_usf_id` int(10) unsigned DEFAULT NULL,
  `lsc_special_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lsc_sort` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lsc_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`lsc_id`),
  KEY `adm2_fk_lsc_lst` (`lsc_lst_id`),
  KEY `adm2_fk_lsc_usf` (`lsc_usf_id`),
  CONSTRAINT `adm2_fk_lsc_lst` FOREIGN KEY (`lsc_lst_id`) REFERENCES `adm2_lists` (`lst_id`),
  CONSTRAINT `adm2_fk_lsc_usf` FOREIGN KEY (`lsc_usf_id`) REFERENCES `adm2_user_fields` (`usf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_lists` (
  `lst_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lst_org_id` int(10) unsigned NOT NULL,
  `lst_usr_id` int(10) unsigned NOT NULL,
  `lst_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `lst_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lst_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lst_global` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lst_id`),
  UNIQUE KEY `adm2_idx_lst_uuid` (`lst_uuid`),
  KEY `adm2_fk_lst_usr` (`lst_usr_id`),
  KEY `adm2_fk_lst_org` (`lst_org_id`),
  CONSTRAINT `adm2_fk_lst_org` FOREIGN KEY (`lst_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_lst_usr` FOREIGN KEY (`lst_usr_id`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_members` (
  `mem_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mem_rol_id` int(10) unsigned NOT NULL,
  `mem_usr_id` int(10) unsigned NOT NULL,
  `mem_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `mem_begin` date NOT NULL,
  `mem_end` date NOT NULL DEFAULT '9999-12-31',
  `mem_leader` tinyint(1) NOT NULL DEFAULT '0',
  `mem_usr_id_create` int(10) unsigned DEFAULT NULL,
  `mem_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mem_usr_id_change` int(10) unsigned DEFAULT NULL,
  `mem_timestamp_change` timestamp NULL DEFAULT NULL,
  `mem_approved` int(10) unsigned DEFAULT NULL,
  `mem_comment` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mem_count_guests` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mem_id`),
  UNIQUE KEY `adm2_idx_mem_uuid` (`mem_uuid`),
  KEY `adm2_idx_mem_rol_usr_id` (`mem_rol_id`,`mem_usr_id`),
  KEY `adm2_fk_mem_usr` (`mem_usr_id`),
  KEY `adm2_fk_mem_usr_create` (`mem_usr_id_create`),
  KEY `adm2_fk_mem_usr_change` (`mem_usr_id_change`),
  CONSTRAINT `adm2_fk_mem_rol` FOREIGN KEY (`mem_rol_id`) REFERENCES `adm2_roles` (`rol_id`),
  CONSTRAINT `adm2_fk_mem_usr` FOREIGN KEY (`mem_usr_id`) REFERENCES `adm2_users` (`usr_id`),
  CONSTRAINT `adm2_fk_mem_usr_change` FOREIGN KEY (`mem_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_mem_usr_create` FOREIGN KEY (`mem_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_menu` (
  `men_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `men_men_id_parent` int(10) unsigned DEFAULT NULL,
  `men_com_id` int(10) unsigned DEFAULT NULL,
  `men_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `men_name_intern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `men_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `men_description` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `men_node` tinyint(1) NOT NULL DEFAULT '0',
  `men_order` int(10) unsigned DEFAULT NULL,
  `men_standard` tinyint(1) NOT NULL DEFAULT '0',
  `men_url` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `men_icon` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`men_id`),
  UNIQUE KEY `adm2_idx_men_uuid` (`men_uuid`),
  KEY `adm2_idx_men_men_id_parent` (`men_men_id_parent`),
  KEY `adm2_fk_men_com_id` (`men_com_id`),
  CONSTRAINT `adm2_fk_men_com_id` FOREIGN KEY (`men_com_id`) REFERENCES `adm2_components` (`com_id`),
  CONSTRAINT `adm2_fk_men_men_parent` FOREIGN KEY (`men_men_id_parent`) REFERENCES `adm2_menu` (`men_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_messages` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msg_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `msg_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `msg_subject` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `msg_usr_id_sender` int(10) unsigned NOT NULL,
  `msg_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `msg_read` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  UNIQUE KEY `adm2_idx_msg_uuid` (`msg_uuid`),
  KEY `adm2_fk_msg_usr_sender` (`msg_usr_id_sender`),
  CONSTRAINT `adm2_fk_msg_usr_sender` FOREIGN KEY (`msg_usr_id_sender`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_messages_attachments` (
  `msa_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msa_msg_id` int(10) unsigned NOT NULL,
  `msa_file_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `msa_original_file_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`msa_id`),
  KEY `adm2_fk_msa_msg_id` (`msa_msg_id`),
  CONSTRAINT `adm2_fk_msa_msg_id` FOREIGN KEY (`msa_msg_id`) REFERENCES `adm2_messages` (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_messages_content` (
  `msc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msc_msg_id` int(10) unsigned NOT NULL,
  `msc_usr_id` int(10) unsigned DEFAULT NULL,
  `msc_message` text COLLATE utf8_unicode_ci NOT NULL,
  `msc_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`msc_id`),
  KEY `adm2_fk_msc_msg_id` (`msc_msg_id`),
  KEY `adm2_fk_msc_usr_id` (`msc_usr_id`),
  CONSTRAINT `adm2_fk_msc_msg_id` FOREIGN KEY (`msc_msg_id`) REFERENCES `adm2_messages` (`msg_id`),
  CONSTRAINT `adm2_fk_msc_usr_id` FOREIGN KEY (`msc_usr_id`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_messages_recipients` (
  `msr_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msr_msg_id` int(10) unsigned NOT NULL,
  `msr_rol_id` int(10) unsigned DEFAULT NULL,
  `msr_usr_id` int(10) unsigned DEFAULT NULL,
  `msr_role_mode` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msr_id`),
  KEY `adm2_fk_msr_msg_id` (`msr_msg_id`),
  KEY `adm2_fk_msr_rol_id` (`msr_rol_id`),
  KEY `adm2_fk_msr_usr_id` (`msr_usr_id`),
  CONSTRAINT `adm2_fk_msr_msg_id` FOREIGN KEY (`msr_msg_id`) REFERENCES `adm2_messages` (`msg_id`),
  CONSTRAINT `adm2_fk_msr_rol_id` FOREIGN KEY (`msr_rol_id`) REFERENCES `adm2_roles` (`rol_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_msr_usr_id` FOREIGN KEY (`msr_usr_id`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_organizations` (
  `org_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `org_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `org_shortname` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `org_longname` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `org_org_id_parent` int(10) unsigned DEFAULT NULL,
  `org_homepage` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`org_id`),
  UNIQUE KEY `adm2_idx_org_shortname` (`org_shortname`),
  UNIQUE KEY `adm2_idx_org_uuid` (`org_uuid`),
  KEY `adm2_fk_org_org_parent` (`org_org_id_parent`),
  CONSTRAINT `adm2_fk_org_org_parent` FOREIGN KEY (`org_org_id_parent`) REFERENCES `adm2_organizations` (`org_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_photos` (
  `pho_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pho_org_id` int(10) unsigned NOT NULL,
  `pho_pho_id_parent` int(10) unsigned DEFAULT NULL,
  `pho_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `pho_quantity` int(10) unsigned NOT NULL DEFAULT '0',
  `pho_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pho_begin` date NOT NULL,
  `pho_end` date NOT NULL,
  `pho_description` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pho_photographers` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pho_locked` tinyint(1) NOT NULL DEFAULT '0',
  `pho_usr_id_create` int(10) unsigned DEFAULT NULL,
  `pho_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pho_usr_id_change` int(10) unsigned DEFAULT NULL,
  `pho_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pho_id`),
  UNIQUE KEY `adm2_idx_pho_uuid` (`pho_uuid`),
  KEY `adm2_fk_pho_pho_parent` (`pho_pho_id_parent`),
  KEY `adm2_fk_pho_org` (`pho_org_id`),
  KEY `adm2_fk_pho_usr_create` (`pho_usr_id_create`),
  KEY `adm2_fk_pho_usr_change` (`pho_usr_id_change`),
  CONSTRAINT `adm2_fk_pho_org` FOREIGN KEY (`pho_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_pho_pho_parent` FOREIGN KEY (`pho_pho_id_parent`) REFERENCES `adm2_photos` (`pho_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_pho_usr_change` FOREIGN KEY (`pho_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_pho_usr_create` FOREIGN KEY (`pho_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_preferences` (
  `prf_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prf_org_id` int(10) unsigned NOT NULL,
  `prf_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `prf_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`prf_id`),
  UNIQUE KEY `adm2_idx_prf_org_id_name` (`prf_org_id`,`prf_name`),
  CONSTRAINT `adm2_fk_prf_org` FOREIGN KEY (`prf_org_id`) REFERENCES `adm2_organizations` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_registrations` (
  `reg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reg_org_id` int(10) unsigned NOT NULL,
  `reg_usr_id` int(10) unsigned NOT NULL,
  `reg_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reg_validation_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`reg_id`),
  KEY `adm2_fk_reg_org` (`reg_org_id`),
  KEY `adm2_fk_reg_usr` (`reg_usr_id`),
  CONSTRAINT `adm2_fk_reg_org` FOREIGN KEY (`reg_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_reg_usr` FOREIGN KEY (`reg_usr_id`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_role_dependencies` (
  `rld_rol_id_parent` int(10) unsigned NOT NULL,
  `rld_rol_id_child` int(10) unsigned NOT NULL,
  `rld_comment` text COLLATE utf8_unicode_ci,
  `rld_usr_id` int(10) unsigned DEFAULT NULL,
  `rld_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rld_rol_id_parent`,`rld_rol_id_child`),
  KEY `adm2_fk_rld_rol_child` (`rld_rol_id_child`),
  KEY `adm2_fk_rld_usr` (`rld_usr_id`),
  CONSTRAINT `adm2_fk_rld_rol_child` FOREIGN KEY (`rld_rol_id_child`) REFERENCES `adm2_roles` (`rol_id`),
  CONSTRAINT `adm2_fk_rld_rol_parent` FOREIGN KEY (`rld_rol_id_parent`) REFERENCES `adm2_roles` (`rol_id`),
  CONSTRAINT `adm2_fk_rld_usr` FOREIGN KEY (`rld_usr_id`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_roles` (
  `rol_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rol_cat_id` int(10) unsigned NOT NULL,
  `rol_lst_id` int(10) unsigned DEFAULT NULL,
  `rol_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `rol_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `rol_description` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rol_assign_roles` tinyint(1) NOT NULL DEFAULT '0',
  `rol_approve_users` tinyint(1) NOT NULL DEFAULT '0',
  `rol_announcements` tinyint(1) NOT NULL DEFAULT '0',
  `rol_events` tinyint(1) NOT NULL DEFAULT '0',
  `rol_documents_files` tinyint(1) NOT NULL DEFAULT '0',
  `rol_edit_user` tinyint(1) NOT NULL DEFAULT '0',
  `rol_guestbook` tinyint(1) NOT NULL DEFAULT '0',
  `rol_guestbook_comments` tinyint(1) NOT NULL DEFAULT '0',
  `rol_mail_to_all` tinyint(1) NOT NULL DEFAULT '0',
  `rol_mail_this_role` smallint(6) NOT NULL DEFAULT '0',
  `rol_photo` tinyint(1) NOT NULL DEFAULT '0',
  `rol_profile` tinyint(1) NOT NULL DEFAULT '0',
  `rol_weblinks` tinyint(1) NOT NULL DEFAULT '0',
  `rol_all_lists_view` tinyint(1) NOT NULL DEFAULT '0',
  `rol_default_registration` tinyint(1) NOT NULL DEFAULT '0',
  `rol_leader_rights` smallint(6) NOT NULL DEFAULT '0',
  `rol_view_memberships` smallint(6) NOT NULL DEFAULT '0',
  `rol_view_members_profiles` smallint(6) NOT NULL DEFAULT '0',
  `rol_start_date` date DEFAULT NULL,
  `rol_start_time` time DEFAULT NULL,
  `rol_end_date` date DEFAULT NULL,
  `rol_end_time` time DEFAULT NULL,
  `rol_weekday` smallint(6) DEFAULT NULL,
  `rol_location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rol_max_members` int(11) DEFAULT NULL,
  `rol_cost` float DEFAULT NULL,
  `rol_cost_period` smallint(6) DEFAULT NULL,
  `rol_usr_id_create` int(10) unsigned DEFAULT NULL,
  `rol_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rol_usr_id_change` int(10) unsigned DEFAULT NULL,
  `rol_timestamp_change` timestamp NULL DEFAULT NULL,
  `rol_valid` tinyint(1) NOT NULL DEFAULT '1',
  `rol_system` tinyint(1) NOT NULL DEFAULT '0',
  `rol_administrator` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rol_id`),
  UNIQUE KEY `adm2_idx_rol_uuid` (`rol_uuid`),
  KEY `adm2_fk_rol_cat` (`rol_cat_id`),
  KEY `adm2_fk_rol_lst_id` (`rol_lst_id`),
  KEY `adm2_fk_rol_usr_create` (`rol_usr_id_create`),
  KEY `adm2_fk_rol_usr_change` (`rol_usr_id_change`),
  CONSTRAINT `adm2_fk_rol_cat` FOREIGN KEY (`rol_cat_id`) REFERENCES `adm2_categories` (`cat_id`),
  CONSTRAINT `adm2_fk_rol_lst_id` FOREIGN KEY (`rol_lst_id`) REFERENCES `adm2_lists` (`lst_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `adm2_fk_rol_usr_change` FOREIGN KEY (`rol_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_rol_usr_create` FOREIGN KEY (`rol_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_roles_rights` (
  `ror_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ror_name_intern` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ror_table` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ror_ror_id_parent` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ror_id`),
  KEY `adm2_fk_ror_ror_parent` (`ror_ror_id_parent`),
  CONSTRAINT `adm2_fk_ror_ror_parent` FOREIGN KEY (`ror_ror_id_parent`) REFERENCES `adm2_roles_rights` (`ror_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_roles_rights_data` (
  `rrd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rrd_ror_id` int(10) unsigned NOT NULL,
  `rrd_rol_id` int(10) unsigned NOT NULL,
  `rrd_object_id` int(10) unsigned NOT NULL,
  `rrd_usr_id_create` int(10) unsigned DEFAULT NULL,
  `rrd_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rrd_id`),
  UNIQUE KEY `adm2_idx_rrd_ror_rol_object_id` (`rrd_ror_id`,`rrd_rol_id`,`rrd_object_id`),
  KEY `adm2_fk_rrd_rol` (`rrd_rol_id`),
  KEY `adm2_fk_rrd_usr_create` (`rrd_usr_id_create`),
  CONSTRAINT `adm2_fk_rrd_rol` FOREIGN KEY (`rrd_rol_id`) REFERENCES `adm2_roles` (`rol_id`),
  CONSTRAINT `adm2_fk_rrd_ror` FOREIGN KEY (`rrd_ror_id`) REFERENCES `adm2_roles_rights` (`ror_id`),
  CONSTRAINT `adm2_fk_rrd_usr_create` FOREIGN KEY (`rrd_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_rooms` (
  `room_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `room_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `room_description` text COLLATE utf8_unicode_ci,
  `room_capacity` int(11) NOT NULL,
  `room_overhang` int(11) DEFAULT NULL,
  `room_usr_id_create` int(10) unsigned DEFAULT NULL,
  `room_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `room_usr_id_change` int(10) unsigned DEFAULT NULL,
  `room_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `adm2_idx_room_uuid` (`room_uuid`),
  KEY `adm2_fk_room_usr_create` (`room_usr_id_create`),
  KEY `adm2_fk_room_usr_change` (`room_usr_id_change`),
  CONSTRAINT `adm2_fk_room_usr_change` FOREIGN KEY (`room_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_room_usr_create` FOREIGN KEY (`room_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_sessions` (
  `ses_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ses_usr_id` int(10) unsigned DEFAULT NULL,
  `ses_org_id` int(10) unsigned NOT NULL,
  `ses_session_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ses_begin` timestamp NULL DEFAULT NULL,
  `ses_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ses_ip_address` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `ses_binary` blob,
  `ses_reload` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ses_id`),
  KEY `adm2_idx_session_id` (`ses_session_id`),
  KEY `adm2_fk_ses_org` (`ses_org_id`),
  KEY `adm2_fk_ses_usr` (`ses_usr_id`),
  CONSTRAINT `adm2_fk_ses_org` FOREIGN KEY (`ses_org_id`) REFERENCES `adm2_organizations` (`org_id`),
  CONSTRAINT `adm2_fk_ses_usr` FOREIGN KEY (`ses_usr_id`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_texts` (
  `txt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `txt_org_id` int(10) unsigned NOT NULL,
  `txt_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `txt_text` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`txt_id`),
  KEY `adm2_fk_txt_org` (`txt_org_id`),
  CONSTRAINT `adm2_fk_txt_org` FOREIGN KEY (`txt_org_id`) REFERENCES `adm2_organizations` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_user_data` (
  `usd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usd_usr_id` int(10) unsigned NOT NULL,
  `usd_usf_id` int(10) unsigned NOT NULL,
  `usd_value` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`usd_id`),
  UNIQUE KEY `adm2_idx_usd_usr_usf_id` (`usd_usr_id`,`usd_usf_id`),
  KEY `adm2_fk_usd_usf` (`usd_usf_id`),
  CONSTRAINT `adm2_fk_usd_usf` FOREIGN KEY (`usd_usf_id`) REFERENCES `adm2_user_fields` (`usf_id`),
  CONSTRAINT `adm2_fk_usd_usr` FOREIGN KEY (`usd_usr_id`) REFERENCES `adm2_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_user_fields` (
  `usf_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usf_cat_id` int(10) unsigned NOT NULL,
  `usf_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `usf_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `usf_name_intern` varchar(110) COLLATE utf8_unicode_ci NOT NULL,
  `usf_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `usf_description` text COLLATE utf8_unicode_ci,
  `usf_description_inline` tinyint(1) NOT NULL DEFAULT '0',
  `usf_value_list` text COLLATE utf8_unicode_ci,
  `usf_default_value` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usf_regex` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usf_icon` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usf_url` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usf_system` tinyint(1) NOT NULL DEFAULT '0',
  `usf_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `usf_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `usf_registration` tinyint(1) NOT NULL DEFAULT '0',
  `usf_required_input` smallint(6) NOT NULL DEFAULT '0',
  `usf_sequence` smallint(6) NOT NULL,
  `usf_usr_id_create` int(10) unsigned DEFAULT NULL,
  `usf_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usf_usr_id_change` int(10) unsigned DEFAULT NULL,
  `usf_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`usf_id`),
  UNIQUE KEY `adm2_idx_usf_name_intern` (`usf_name_intern`),
  UNIQUE KEY `adm2_idx_usf_uuid` (`usf_uuid`),
  KEY `adm2_fk_usf_cat` (`usf_cat_id`),
  KEY `adm2_fk_usf_usr_create` (`usf_usr_id_create`),
  KEY `adm2_fk_usf_usr_change` (`usf_usr_id_change`),
  CONSTRAINT `adm2_fk_usf_cat` FOREIGN KEY (`usf_cat_id`) REFERENCES `adm2_categories` (`cat_id`),
  CONSTRAINT `adm2_fk_usf_usr_change` FOREIGN KEY (`usf_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_usf_usr_create` FOREIGN KEY (`usf_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_user_log` (
  `usl_id` int(11) NOT NULL AUTO_INCREMENT,
  `usl_usr_id` int(10) unsigned NOT NULL,
  `usl_usf_id` int(10) unsigned NOT NULL,
  `usl_value_old` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usl_value_new` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usl_usr_id_create` int(10) unsigned DEFAULT NULL,
  `usl_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usl_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`usl_id`),
  KEY `adm2_fk_user_log_1` (`usl_usr_id`),
  KEY `adm2_fk_user_log_2` (`usl_usr_id_create`),
  KEY `adm2_fk_user_log_3` (`usl_usf_id`),
  CONSTRAINT `adm2_fk_user_log_1` FOREIGN KEY (`usl_usr_id`) REFERENCES `adm2_users` (`usr_id`),
  CONSTRAINT `adm2_fk_user_log_2` FOREIGN KEY (`usl_usr_id_create`) REFERENCES `adm2_users` (`usr_id`),
  CONSTRAINT `adm2_fk_user_log_3` FOREIGN KEY (`usl_usf_id`) REFERENCES `adm2_user_fields` (`usf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_user_relation_types` (
  `urt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `urt_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `urt_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `urt_name_male` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `urt_name_female` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `urt_edit_user` tinyint(1) NOT NULL DEFAULT '0',
  `urt_id_inverse` int(10) unsigned DEFAULT NULL,
  `urt_usr_id_create` int(10) unsigned DEFAULT NULL,
  `urt_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `urt_usr_id_change` int(10) unsigned DEFAULT NULL,
  `urt_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`urt_id`),
  UNIQUE KEY `adm2_idx_ure_urt_name` (`urt_name`),
  UNIQUE KEY `adm2_idx_urt_uuid` (`urt_uuid`),
  KEY `adm2_fk_urt_id_inverse` (`urt_id_inverse`),
  KEY `adm2_fk_urt_usr_change` (`urt_usr_id_change`),
  KEY `adm2_fk_urt_usr_create` (`urt_usr_id_create`),
  CONSTRAINT `adm2_fk_urt_id_inverse` FOREIGN KEY (`urt_id_inverse`) REFERENCES `adm2_user_relation_types` (`urt_id`) ON DELETE CASCADE,
  CONSTRAINT `adm2_fk_urt_usr_change` FOREIGN KEY (`urt_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_urt_usr_create` FOREIGN KEY (`urt_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_user_relations` (
  `ure_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ure_urt_id` int(10) unsigned NOT NULL,
  `ure_usr_id1` int(10) unsigned NOT NULL,
  `ure_usr_id2` int(10) unsigned NOT NULL,
  `ure_usr_id_create` int(10) unsigned DEFAULT NULL,
  `ure_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ure_usr_id_change` int(10) unsigned DEFAULT NULL,
  `ure_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ure_id`),
  UNIQUE KEY `adm2_idx_ure_urt_usr` (`ure_urt_id`,`ure_usr_id1`,`ure_usr_id2`),
  KEY `adm2_fk_ure_usr1` (`ure_usr_id1`),
  KEY `adm2_fk_ure_usr2` (`ure_usr_id2`),
  KEY `adm2_fk_ure_usr_change` (`ure_usr_id_change`),
  KEY `adm2_fk_ure_usr_create` (`ure_usr_id_create`),
  CONSTRAINT `adm2_fk_ure_urt` FOREIGN KEY (`ure_urt_id`) REFERENCES `adm2_user_relation_types` (`urt_id`) ON DELETE CASCADE,
  CONSTRAINT `adm2_fk_ure_usr1` FOREIGN KEY (`ure_usr_id1`) REFERENCES `adm2_users` (`usr_id`) ON DELETE CASCADE,
  CONSTRAINT `adm2_fk_ure_usr2` FOREIGN KEY (`ure_usr_id2`) REFERENCES `adm2_users` (`usr_id`) ON DELETE CASCADE,
  CONSTRAINT `adm2_fk_ure_usr_change` FOREIGN KEY (`ure_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_ure_usr_create` FOREIGN KEY (`ure_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `adm2_users` (
  `usr_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usr_uuid` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `usr_login_name` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_photo` blob,
  `usr_text` text COLLATE utf8_unicode_ci,
  `usr_pw_reset_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_pw_reset_timestamp` timestamp NULL DEFAULT NULL,
  `usr_last_login` timestamp NULL DEFAULT NULL,
  `usr_actual_login` timestamp NULL DEFAULT NULL,
  `usr_number_login` int(11) NOT NULL DEFAULT '0',
  `usr_date_invalid` timestamp NULL DEFAULT NULL,
  `usr_number_invalid` smallint(6) NOT NULL DEFAULT '0',
  `usr_usr_id_create` int(10) unsigned DEFAULT NULL,
  `usr_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usr_usr_id_change` int(10) unsigned DEFAULT NULL,
  `usr_timestamp_change` timestamp NULL DEFAULT NULL,
  `usr_valid` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`usr_id`),
  UNIQUE KEY `adm2_idx_usr_uuid` (`usr_uuid`),
  UNIQUE KEY `adm2_idx_usr_login_name` (`usr_login_name`),
  KEY `adm2_fk_usr_usr_create` (`usr_usr_id_create`),
  KEY `adm2_fk_usr_usr_change` (`usr_usr_id_change`),
  CONSTRAINT `adm2_fk_usr_usr_change` FOREIGN KEY (`usr_usr_id_change`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `adm2_fk_usr_usr_create` FOREIGN KEY (`usr_usr_id_create`) REFERENCES `adm2_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;





# dumping data for admidio.adm2_categories
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (1, NULL, 'df29fdcc-bf0c-4df1-ab83-cb7b84174d0c', 'USF', 'BASIC_DATA', 'SYS_BASIC_DATA', 1, 0, 1, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (2, NULL, 'b24dbe1f-2934-4438-b267-51217e05fc71', 'USF', 'SOCIAL_NETWORKS', 'SYS_SOCIAL_NETWORKS', 0, 0, 2, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (3, NULL, '019592d8-1808-436a-a96b-d9a187d47ce4', 'USF', 'ADDIDIONAL_DATA', 'INS_ADDIDIONAL_DATA', 0, 0, 3, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (4, 1, 'bf8c9e32-9a58-4a46-9a8a-cb61b60f80ab', 'ROL', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (5, 1, 'd5996c4b-5987-49f6-a62a-1489c838e4c9', 'ROL', 'GROUPS', 'INS_GROUPS', 0, 0, 2, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (6, 1, '43195618-ea10-485c-9bc6-d7a3be1cbd60', 'ROL', 'COURSES', 'INS_COURSES', 0, 0, 3, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (7, 1, 'b4a85470-50d8-466e-b0a2-debd3e09b9ea', 'ROL', 'TEAMS', 'INS_TEAMS', 0, 0, 4, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (8, 1, '50ddb27d-3ec9-4ee7-a12d-e07a2305ecdc', 'ROL', 'EVENTS', 'SYS_EVENTS_CONFIRMATION_OF_PARTICIPATION', 1, 0, 5, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (9, 1, '2123bc9b-e60f-4379-a4be-c34734b0796a', 'LNK', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (10, 1, '2199298e-e093-4663-a068-e96f5e37346c', 'LNK', 'INTERN', 'INS_INTERN', 0, 0, 2, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (11, 1, 'ddf07a43-6e21-43f2-8def-58a753dc6290', 'ANN', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (12, 1, '7f71b341-5af5-428b-a1cc-dc6101fbea2e', 'ANN', 'IMPORTANT', 'SYS_IMPORTANT', 0, 0, 2, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (13, 1, 'e523b485-a9a3-4249-be16-9fa186e277cf', 'DAT', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (14, 1, 'a15f1d20-0b7e-4abc-b13b-e06231a08e0f', 'DAT', 'TRAINING', 'INS_TRAINING', 0, 0, 2, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (15, 1, '96d17c0d-daa0-4dd2-a152-5d832cd6ad0f', 'DAT', 'COURSES', 'INS_COURSES', 0, 0, 3, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (16, 1, '3946504a-3dc7-48b1-ac59-cd5e0f1d8a86', 'EVT', 'TEST', 'test', 0, 0, 1, 2, '2024-04-03 14:01:14', NULL, NULL);


# dumping data for admidio.adm2_category_report
INSERT INTO `adm2_category_report` (`crt_id`, `crt_org_id`, `crt_name`, `crt_col_fields`, `crt_selection_role`, `crt_selection_cat`, `crt_number_col`) VALUES (1, 1, 'General role assignment', 'p2,p1,p3,p5,r1,r3,r2', NULL, NULL, 0);


# dumping data for admidio.adm2_components
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (1, 'SYSTEM', 'Admidio Core', 'CORE', '4.3.6', 0, 1150, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (2, 'MODULE', 'SYS_ANNOUNCEMENTS', 'ANNOUNCEMENTS', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (3, 'MODULE', 'SYS_DATABASE_BACKUP', 'BACKUP', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (4, 'MODULE', 'SYS_CATEGORIES', 'CATEGORIES', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (5, 'MODULE', 'SYS_CATEGORY_REPORT', 'CATEGORY-REPORT', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (6, 'MODULE', 'SYS_EVENTS', 'EVENTS', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (7, 'MODULE', 'SYS_DOCUMENTS_FILES', 'DOCUMENTS-FILES', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (8, 'MODULE', 'GBO_GUESTBOOK', 'GUESTBOOK', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (9, 'MODULE', 'SYS_WEBLINKS', 'LINKS', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (10, 'MODULE', 'SYS_GROUPS_ROLES', 'GROUPS-ROLES', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (11, 'MODULE', 'SYS_CONTACTS', 'CONTACTS', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (12, 'MODULE', 'SYS_MESSAGES', 'MESSAGES', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (13, 'MODULE', 'SYS_MENU', 'MENU', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (14, 'MODULE', 'SYS_PHOTOS', 'PHOTOS', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (15, 'MODULE', 'SYS_SETTINGS', 'PREFERENCES', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (16, 'MODULE', 'SYS_PROFILE', 'PROFILE', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (17, 'MODULE', 'SYS_REGISTRATION', 'REGISTRATION', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');
INSERT INTO `adm2_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (18, 'MODULE', 'SYS_ROOM_MANAGEMENT', 'ROOMS', '4.3.6', 0, 0, 1, '2024-04-03 13:59:59');


# dumping data for admidio.adm2_events
INSERT INTO `adm2_events` (`dat_id`, `dat_cat_id`, `dat_rol_id`, `dat_room_id`, `dat_uuid`, `dat_begin`, `dat_end`, `dat_all_day`, `dat_headline`, `dat_description`, `dat_highlight`, `dat_location`, `dat_country`, `dat_deadline`, `dat_max_members`, `dat_usr_id_create`, `dat_timestamp_create`, `dat_usr_id_change`, `dat_timestamp_change`, `dat_allow_comments`, `dat_additional_guests`) VALUES (1, 16, 4, NULL, '5e63dccb-d409-4edd-a4bc-eeed10c1bacc', '2024-04-10 15:00:00', '2024-04-12 17:00:00', 0, 'Durga Puja', '<p>test</p>\n', 1, NULL, NULL, '2024-04-09 00:00:00', 0, 2, '2024-04-03 14:18:44', NULL, NULL, 1, 0);




# dumping data for admidio.adm2_folders
INSERT INTO `adm2_folders` (`fol_id`, `fol_org_id`, `fol_fol_id_parent`, `fol_uuid`, `fol_type`, `fol_name`, `fol_description`, `fol_path`, `fol_locked`, `fol_public`, `fol_usr_id`, `fol_timestamp`) VALUES (1, 1, NULL, '49d4a41a-842e-44d8-9c3c-da1471a48b56', 'DOCUMENTS', 'documents_bcaa', NULL, '/adm_my_files', 0, 1, 1, '2024-04-03 13:59:50');










# dumping data for admidio.adm2_list_columns
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (1, 1, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (2, 1, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (3, 1, 3, 9, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (4, 1, 4, 3, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (5, 1, 5, 4, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (6, 1, 6, 5, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (7, 2, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (8, 2, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (10, 2, 3, 8, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (11, 2, 4, 11, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (12, 3, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (13, 3, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (14, 3, 3, 9, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (15, 3, 4, 3, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (16, 3, 5, 4, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (17, 3, 6, 5, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (19, 3, 7, 8, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (20, 3, 8, 11, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (21, 4, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (22, 4, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (23, 4, 3, 9, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (24, 4, 4, NULL, 'mem_begin', NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (25, 4, 5, NULL, 'mem_end', NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (26, 5, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (27, 5, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (28, 5, 3, NULL, 'mem_approved', NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (29, 5, 4, NULL, 'mem_comment', NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (30, 5, 5, NULL, 'mem_count_guests', NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (31, 6, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (32, 6, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (33, 6, 3, NULL, 'usr_login_name', NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (34, 6, 4, 10, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (35, 6, 5, 9, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (36, 6, 6, 5, NULL, NULL, NULL);
INSERT INTO `adm2_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (37, 6, 7, NULL, 'usr_timestamp_change', NULL, NULL);


# dumping data for admidio.adm2_lists
INSERT INTO `adm2_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (1, 1, 1, '73795eb2-0349-45a0-af08-b3b7bd42ce5f', 'Address list', '2024-04-03 13:59:50', 1);
INSERT INTO `adm2_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (2, 1, 1, '40bb24f7-1644-4f02-87a0-6d8656267d33', 'Phone list', '2024-04-03 13:59:50', 1);
INSERT INTO `adm2_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (3, 1, 1, '94e06a22-ea67-4ce7-ac2f-b762864b6dd3', 'Contact information', '2024-04-03 13:59:50', 1);
INSERT INTO `adm2_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (4, 1, 1, '63304acc-701d-4b3e-83e4-32055a0d9863', 'Membership', '2024-04-03 13:59:50', 1);
INSERT INTO `adm2_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (5, 1, 1, 'bdc90776-96b2-47c3-ae29-97c2207ae05c', 'Members', '2024-04-03 13:59:50', 1);
INSERT INTO `adm2_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (6, 1, 1, 'cfe9098e-5e63-46cb-87fd-c7bd2ba44b14', 'Contacts', '2024-04-03 13:59:50', 1);


# dumping data for admidio.adm2_members
INSERT INTO `adm2_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (1, 1, 2, 'a7646ee6-a6cf-46e2-a9a8-f72c66937233', '2024-04-03', '9999-12-31', 0, 1, '2024-04-03 13:59:50', NULL, NULL, NULL, NULL, 0);
INSERT INTO `adm2_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (2, 2, 2, '47475639-c4f1-41fe-abab-737506b1c818', '2024-04-03', '9999-12-31', 0, 1, '2024-04-03 13:59:50', NULL, NULL, NULL, NULL, 0);
INSERT INTO `adm2_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (3, 2, 3, '6ce5c706-7ed4-4b88-a0d7-301bdbf3e505', '2024-04-03', '9999-12-31', 0, 2, '2024-04-03 14:09:17', NULL, NULL, NULL, NULL, 0);
INSERT INTO `adm2_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (4, 2, 4, 'e2c9b74b-eb67-481d-941d-1448b8c9cc06', '2024-04-03', '9999-12-31', 0, 2, '2024-04-03 14:10:29', NULL, NULL, NULL, NULL, 0);
INSERT INTO `adm2_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (5, 4, 2, '00dc25bb-8d87-43f7-b802-0c62f309881f', '2024-04-03', '9999-12-31', 1, 2, '2024-04-03 14:18:44', NULL, NULL, 2, NULL, 0);
INSERT INTO `adm2_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (6, 4, 4, '0bfaa013-9d47-4465-b1b7-57981eac6e72', '2024-04-03', '9999-12-31', 0, 2, '2024-04-03 14:18:58', NULL, NULL, 2, NULL, 0);
INSERT INTO `adm2_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (7, 4, 3, 'c7235f62-bacc-42c4-baeb-3f95d91620bb', '2024-04-03', '9999-12-31', 0, 2, '2024-04-03 14:19:13', NULL, NULL, 2, NULL, 0);


# dumping data for admidio.adm2_menu
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (1, NULL, NULL, 'fcc951ce-1d46-445e-b236-551796a97a55', 'modules', 'SYS_MODULES', '', 1, 1, 1, NULL, '');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (2, NULL, NULL, '9dc7e84d-a480-4c58-b8c6-0d24f722fc26', 'administration', 'SYS_ADMINISTRATION', '', 1, 2, 1, NULL, '');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (3, NULL, NULL, '06bf4faa-409e-48c0-9080-7883a0338872', 'plugins', 'SYS_PLUGINS', '', 1, 3, 1, NULL, '');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (4, 1, NULL, '2925eabd-17e6-40ae-bf5f-4f0fbbf8bbbd', 'overview', 'SYS_OVERVIEW', '', 0, 1, 1, '/adm_program/overview.php', 'fa-home');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (5, 1, 2, '61a44e2f-5549-42b9-bc2e-703a91b47c61', 'announcements', 'SYS_ANNOUNCEMENTS', 'SYS_ANNOUNCEMENTS_DESC', 0, 2, 1, '/adm_program/modules/announcements/announcements.php', 'fa-newspaper');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (6, 1, 6, '540993f5-3ae8-444a-bbc3-9c3389c18961', 'events', 'SYS_EVENTS', 'SYS_EVENTS_DESC', 0, 3, 1, '/adm_program/modules/events/events.php', 'fa-calendar-alt');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (7, 1, 12, '757c5d69-4377-46c0-9a97-8fae6cc9f421', 'messages', 'SYS_MESSAGES', 'SYS_MESSAGES_DESC', 0, 4, 1, '/adm_program/modules/messages/messages.php', 'fa-comments');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (8, 1, 10, '86595e35-b982-47ca-8cf6-5a210217dff0', 'groups-roles', 'SYS_GROUPS_ROLES', 'SYS_GROUPS_ROLES_DESC', 0, 5, 1, '/adm_program/modules/groups-roles/groups_roles.php', 'fa-users');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (9, 1, 11, 'c7196dab-d743-4bfe-93c9-435f98b91585', 'contacts', 'SYS_CONTACTS', 'SYS_CONTACTS_DESC', 0, 6, 1, '/adm_program/modules/contacts/contacts.php', 'fa-address-card');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (10, 1, 7, 'b7729fd4-9a10-4e0c-b179-96c3ffe0aa35', 'documents-files', 'SYS_DOCUMENTS_FILES', 'SYS_DOCUMENTS_FILES_DESC', 0, 7, 1, '/adm_program/modules/documents-files/documents_files.php', 'fa-file-download');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (11, 1, 14, '57e5cb33-e662-42c2-81cc-a7f4bf2e7e06', 'photo', 'SYS_PHOTOS', 'SYS_PHOTOS_DESC', 0, 8, 1, '/adm_program/modules/photos/photos.php', 'fa-image');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (12, 1, 5, '3e4f3b82-08c7-4a74-b188-8582ec51343f', 'category-report', 'SYS_CATEGORY_REPORT', 'SYS_CATEGORY_REPORT_DESC', 0, 9, 1, '/adm_program/modules/category-report/category_report.php', 'fa-list-ul');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (13, 1, 9, 'cfc3472a-7cf0-4ba9-906e-d3f94c5b9b85', 'weblinks', 'SYS_WEBLINKS', 'SYS_WEBLINKS_DESC', 0, 10, 1, '/adm_program/modules/links/links.php', 'fa-link');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (14, 1, 8, 'b3d30aba-c515-4e36-aaf0-12972a7c0879', 'guestbook', 'GBO_GUESTBOOK', 'GBO_GUESTBOOK_DESC', 0, 11, 1, '/adm_program/modules/guestbook/guestbook.php', 'fa-book');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (15, 2, 15, 'b36c9be6-6037-4960-ad0c-a0d035aa038d', 'orgprop', 'SYS_SETTINGS', 'ORG_ORGANIZATION_PROPERTIES_DESC', 0, 1, 1, '/adm_program/modules/preferences/preferences.php', 'fa-cog');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (16, 2, 17, '8fa3ef50-8fba-455e-9ebd-f167a89accc4', 'registration', 'SYS_REGISTRATIONS', 'SYS_MANAGE_NEW_REGISTRATIONS_DESC', 0, 2, 1, '/adm_program/modules/registration/registration.php', 'fa-file-signature');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (17, 2, 13, '2c0be1fe-2bed-46b7-a02e-c293e2b58c64', 'menu', 'SYS_MENU', 'SYS_MENU_DESC', 0, 3, 1, '/adm_program/modules/menu/menu.php', 'fa-stream');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (18, 2, 3, 'a4ffc49e-30be-4228-83b9-59feaa2dc0ec', 'dbback', 'SYS_DATABASE_BACKUP', 'SYS_DATABASE_BACKUP_DESC', 0, 4, 1, '/adm_program/modules/backup/backup.php', 'fa-database');
INSERT INTO `adm2_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (19, 2, NULL, 'a7ea8a12-10b1-4311-9d94-17befdfac647', 'CUSTOM_FUNCTION', 'Custom Function', NULL, 0, 5, 0, '/custom_ui/custom.html', NULL);










# dumping data for admidio.adm2_organizations
INSERT INTO `adm2_organizations` (`org_id`, `org_uuid`, `org_shortname`, `org_longname`, `org_org_id_parent`, `org_homepage`) VALUES (1, 'ee3f358d-5a1f-468e-bd54-fdecd2e0d706', 'BCAA', 'BCAA', NULL, 'http://localhost:9000/admidio');




# dumping data for admidio.adm2_preferences
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (1, 1, 'enable_rss', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (2, 1, 'enable_auto_login', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (3, 1, 'default_country', 'DEU');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (4, 1, 'logout_minutes', '20');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (5, 1, 'homepage_logout', 'adm_program/overview.php');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (6, 1, 'homepage_login', 'adm_program/overview.php');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (7, 1, 'theme', 'simple');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (8, 1, 'enable_password_recovery', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (9, 1, 'system_browser_update_check', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (10, 1, 'system_cookie_note', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (11, 1, 'system_currency', '€');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (12, 1, 'system_date', 'd.m.Y');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (13, 1, 'system_hashing_cost', '12');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (14, 1, 'system_js_editor_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (15, 1, 'system_js_editor_color', '#96c4cb');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (16, 1, 'system_language', 'en');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (17, 1, 'system_search_similar', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (18, 1, 'system_show_create_edit', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (19, 1, 'system_time', 'H:i');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (20, 1, 'system_url_imprint', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (21, 1, 'system_url_data_protection', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (22, 1, 'password_min_strength', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (23, 1, 'email_administrator', 'subhas.sing@gmail.com');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (24, 1, 'system_organization_select', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (25, 1, 'registration_adopt_all_data', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (26, 1, 'registration_enable_captcha', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (27, 1, 'registration_enable_module', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (28, 1, 'registration_manual_approval', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (29, 1, 'registration_send_notification_email', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (30, 1, 'mail_send_method', 'phpmail');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (31, 1, 'mail_sending_mode', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (32, 1, 'mail_recipients_with_roles', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (33, 1, 'mail_number_recipients', '50');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (34, 1, 'mail_into_to', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (35, 1, 'mail_character_encoding', 'utf-8');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (36, 1, 'mail_smtp_host', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (37, 1, 'mail_smtp_auth', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (38, 1, 'mail_smtp_port', '587');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (39, 1, 'mail_smtp_secure', 'tls');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (40, 1, 'mail_smtp_authentication_type', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (41, 1, 'mail_smtp_user', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (42, 1, 'mail_smtp_password', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (43, 1, 'system_notifications_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (44, 1, 'system_notifications_role', 'd94f392f-7159-4991-a01d-f875cc786e55');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (45, 1, 'system_notifications_new_entries', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (46, 1, 'system_notifications_profile_changes', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (47, 1, 'captcha_type', 'pic');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (48, 1, 'captcha_fonts', 'AHGBold.ttf');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (49, 1, 'captcha_width', '215');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (50, 1, 'captcha_lines_numbers', '5');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (51, 1, 'captcha_perturbation', '0.75');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (52, 1, 'captcha_background_image', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (53, 1, 'captcha_background_color', '#B6D6DB');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (54, 1, 'captcha_text_color', '#707070');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (55, 1, 'captcha_line_color', '#707070');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (56, 1, 'captcha_charset', '23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxy');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (57, 1, 'captcha_signature', 'Powered by Admidio.org');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (58, 1, 'announcements_module_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (59, 1, 'announcements_per_page', '10');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (60, 1, 'category_report_enable_module', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (61, 1, 'category_report_default_configuration', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (62, 1, 'contacts_field_history_days', '365');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (63, 1, 'contacts_list_configuration', '6');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (64, 1, 'contacts_per_page', '25');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (65, 1, 'contacts_show_all', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (66, 1, 'contacts_user_relations_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (67, 1, 'documents_files_module_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (68, 1, 'documents_files_max_upload_size', '3');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (69, 1, 'events_list_configuration', '5');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (70, 1, 'events_ical_export_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (71, 1, 'events_ical_days_past', '30');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (72, 1, 'events_ical_days_future', '365');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (73, 1, 'events_may_take_part', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (74, 1, 'events_module_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (75, 1, 'events_per_page', '10');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (76, 1, 'events_rooms_enabled', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (77, 1, 'events_save_cancellations', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (78, 1, 'events_show_map_link', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (79, 1, 'events_view', 'detail');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (80, 1, 'groups_roles_default_configuration', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (81, 1, 'groups_roles_enable_module', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (82, 1, 'groups_roles_export', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (83, 1, 'groups_roles_edit_lists', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (84, 1, 'groups_roles_members_per_page', '25');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (85, 1, 'groups_roles_show_former_members', '2');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (86, 1, 'enable_guestbook_module', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (87, 1, 'guestbook_entries_per_page', '10');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (88, 1, 'enable_guestbook_captcha', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (89, 1, 'flooding_protection_time', '60');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (90, 1, 'enable_gbook_comments4all', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (91, 1, 'enable_intial_comments_loading', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (92, 1, 'enable_guestbook_moderation', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (93, 1, 'enable_mail_module', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (94, 1, 'enable_pm_module', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (95, 1, 'enable_mail_captcha', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (96, 1, 'mail_delivery_confirmation', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (97, 1, 'mail_html_registered_users', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (98, 1, 'mail_max_receiver', '10');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (99, 1, 'mail_save_attachments', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (100, 1, 'mail_send_to_all_addresses', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (101, 1, 'mail_sendmail_address', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (102, 1, 'mail_sendmail_name', '');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (103, 1, 'mail_show_former', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (104, 1, 'mail_template', 'default.html');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (105, 1, 'max_email_attachment_size', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (106, 1, 'photo_albums_per_page', '24');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (107, 1, 'photo_download_enabled', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (108, 1, 'photo_ecard_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (109, 1, 'photo_ecard_scale', '500');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (110, 1, 'photo_ecard_template', 'postcard.tpl');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (111, 1, 'photo_image_text', '© localhost');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (112, 1, 'photo_image_text_size', '40');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (113, 1, 'photo_keep_original', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (114, 1, 'photo_module_enabled', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (115, 1, 'photo_show_width', '1000');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (116, 1, 'photo_show_height', '800');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (117, 1, 'photo_show_mode', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (118, 1, 'photo_thumbs_page', '16');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (119, 1, 'photo_thumbs_scale', '200');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (120, 1, 'profile_log_edit_fields', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (121, 1, 'profile_show_map_link', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (122, 1, 'profile_show_roles', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (123, 1, 'profile_show_former_roles', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (124, 1, 'profile_show_extern_roles', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (125, 1, 'profile_photo_storage', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (126, 1, 'enable_weblinks_module', '1');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (127, 1, 'weblinks_per_page', '0');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (128, 1, 'weblinks_redirect_seconds', '10');
INSERT INTO `adm2_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (129, 1, 'weblinks_target', '_blank');






# dumping data for admidio.adm2_roles
INSERT INTO `adm2_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_uuid`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_events`, `rol_documents_files`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_view_memberships`, `rol_view_members_profiles`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_administrator`) VALUES (1, 4, NULL, 'd94f392f-7159-4991-a01d-f875cc786e55', 'Administrator', 'Group of system administrators', 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2024-04-03 13:59:50', NULL, NULL, 1, 0, 1);
INSERT INTO `adm2_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_uuid`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_events`, `rol_documents_files`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_view_memberships`, `rol_view_members_profiles`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_administrator`) VALUES (2, 4, NULL, 'f1592bdf-059c-4ff6-950c-7139b733c31b', 'Member', 'All organization members', 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 1, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2024-04-03 13:59:50', NULL, NULL, 1, 0, 0);
INSERT INTO `adm2_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_uuid`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_events`, `rol_documents_files`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_view_memberships`, `rol_view_members_profiles`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_administrator`) VALUES (3, 4, NULL, '000fad7e-19e7-4794-ade5-7f45806d9793', 'Association&rsquo;s board', 'Administrative board of association', 0, 0, 1, 1, 0, 1, 0, 0, 1, 2, 0, 1, 1, 1, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2024-04-03 13:59:50', NULL, NULL, 1, 0, 0);
INSERT INTO `adm2_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_uuid`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_events`, `rol_documents_files`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_view_memberships`, `rol_view_members_profiles`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_administrator`) VALUES (4, 8, NULL, 'c185765b-38db-48d8-ad7d-5a570c6f4a97', '10.04.2024 15:00 Durga Puja', 'test', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, '2024-04-03 14:18:44', NULL, NULL, 1, 0, 0);


# dumping data for admidio.adm2_roles_rights
INSERT INTO `adm2_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (1, 'folder_view', 'adm_folders', NULL);
INSERT INTO `adm2_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (2, 'folder_upload', 'adm_folders', NULL);
INSERT INTO `adm2_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (3, 'category_view', 'adm_categories', NULL);
INSERT INTO `adm2_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (4, 'event_participation', 'adm_dates', NULL);
INSERT INTO `adm2_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (5, 'menu_view', 'adm_menu', NULL);
INSERT INTO `adm2_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (6, 'category_edit', 'adm_categories', 3);


# dumping data for admidio.adm2_roles_rights_data
INSERT INTO `adm2_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (1, 6, 1, 16, 2, '2024-04-03 14:01:14');
INSERT INTO `adm2_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (2, 4, 2, 1, 2, '2024-04-03 14:18:44');
INSERT INTO `adm2_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (3, 5, 1, 19, 2, '2024-04-03 15:35:55');
INSERT INTO `adm2_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (4, 5, 3, 19, 2, '2024-04-03 15:35:55');


# dumping data for admidio.adm2_rooms
INSERT INTO `adm2_rooms` (`room_id`, `room_uuid`, `room_name`, `room_description`, `room_capacity`, `room_overhang`, `room_usr_id_create`, `room_timestamp_create`, `room_usr_id_change`, `room_timestamp_change`) VALUES (1, '37186b4b-cbe5-4afd-9128-84a7095d672e', 'Conference room', 'Meetings can take place here.', 15, NULL, 1, '2024-04-03 13:59:50', NULL, NULL);


# dumping data for admidio.adm2_sessions
INSERT INTO `adm2_sessions` (`ses_id`, `ses_usr_id`, `ses_org_id`, `ses_session_id`, `ses_begin`, `ses_timestamp`, `ses_ip_address`, `ses_binary`, `ses_reload`) VALUES (7, 2, 1, '0rro9cf44mbsaishbtrv3m9qus', '2024-04-10 14:53:08', '2024-04-10 16:58:38', ':XXXX:XXXX', NULL, 0);


# dumping data for admidio.adm2_texts
INSERT INTO `adm2_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (1, 1, 'SYSMAIL_REGISTRATION_CONFIRMATION', '#subject# Your registration at #organization_long_name#\r\n#content# Hello #user_first_name#,\r\nwe are very glad that you have registered on our website #organization_homepage#.\r\n\r\nTo complete your registration, please click on the following link: #variable1#. By clicking on the link you will be automatically redirected to our website and your registration will be confirmed.\r\n\r\nOnce you have confirmed your registration, we will check it. You will receive a reply within a few hours whether your registration has been accepted and you can log in with your credentials or whether your registration has been rejected.\r\n\r\nBest regards\r\nThe team of #organization_long_name#');
INSERT INTO `adm2_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (2, 1, 'SYSMAIL_REGISTRATION_NEW', '#subject# New registration at #organization_long_name# website\r\n#content# A new user has registered on #organization_homepage#.\r\n\r\nSurname: #user_last_name#\r\nFirst Name: #user_first_name#\r\nE-Mail: #user_email#\r\n\r\n\r\nThis message was generated automatically.');
INSERT INTO `adm2_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (3, 1, 'SYSMAIL_REGISTRATION_APPROVED', '#subject# Registration at #organization_long_name# confirmed\r\n#content# Hello #user_first_name#,\r\n\r\nyour registration on #organization_homepage# has been confirmed.\r\n\r\nYou can now log in to the homepage with your username #user_login_name# and your password.\r\n\r\nIf you have any questions, write an email to #administrator_email#.\r\n\r\nRegards,\r\nThe team of #organization_long_name#');
INSERT INTO `adm2_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (4, 1, 'SYSMAIL_REGISTRATION_REFUSED', '#subject# in registration at #organization_long_name# rejected.\r\n#content#Hello #user_first_name#,\r\n\r\nyour registration at #organization_homepage# was rejected.\r\n\r\nRegistrations are accepted in general by our users. If you are a member and your registration was still rejected, it may be because you were not identified as member.\r\nTo clarify the reasons for the rejection please contact the administrator #administrator_email# from #organization_homepage#.\r\n\r\nRegards,\r\nThe team of #organization_long_name#');
INSERT INTO `adm2_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (5, 1, 'SYSMAIL_NEW_PASSWORD', '#subject# Login data for #organization_long_name#\r\n#content# Hello #user_first_name#,\r\n\r\nYou receive your login data for the website #organization_homepage#.\r\nUsername: #user_login_name#\r\nPassword: #variable1#\r\n\r\nThe password was generated automatically,\r\nYou should change it after logging in to #organization_homepage# in your profile.\r\n\r\nRegards,\r\nThe team of #organization_long_name#');
INSERT INTO `adm2_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (6, 1, 'SYSMAIL_PASSWORD_RESET', '#subject# Reset password for #organization_long_name#\r\n#content# Hello #user_first_name#,\r\n\r\nWe have received a request to reset your password on #organization_homepage#.\r\n\r\nIf the request came from you, you can use the following link to reset your password and set a new one: \r\n#variable1#\r\n\r\nRegards,\r\nThe team of #organization_long_name#');


# dumping data for admidio.adm2_user_data
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (1, 2, 1, 'Sing');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (2, 2, 2, 'Subhas');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (3, 2, 11, 'subhas.sing@gmail.com');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (4, 1, 1, 'System');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (5, 3, 1, 'Majumdar');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (6, 3, 2, 'Popy');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (8, 3, 10, '2');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (9, 4, 1, 'Sing');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (10, 4, 2, 'Raunak');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (12, 4, 10, '1');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (13, 3, 11, 'popy.majumdar@gmail.com');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (14, 3, 23, '2024-04-01');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (15, 3, 24, '0');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (16, 4, 23, '2024-04-05');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (17, 4, 24, '1');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (18, 4, 11, 'test@test.com');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (19, 2, 24, '0');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (20, 3, 8, '480-319-5677');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (21, 3, 25, '3');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (22, 4, 25, '2');
INSERT INTO `adm2_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (23, 2, 25, '2');


# dumping data for admidio.adm2_user_fields
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (1, 1, '0de6813b-6392-4843-b308-5d6302e1a845', 'TEXT', 'LAST_NAME', 'SYS_LASTNAME', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, 1, 1, 1, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (2, 1, '999f8a4a-ed2e-4b39-8244-7280e6be72dd', 'TEXT', 'FIRST_NAME', 'SYS_FIRSTNAME', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, 1, 1, 2, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (3, 1, 'ce8831f5-d4f9-44a5-94fc-5d82dfc91a91', 'TEXT', 'STREET', 'SYS_STREET', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 3, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (4, 1, 'd73bd90b-192d-4fb4-abb2-ff8adf653b81', 'TEXT', 'POSTCODE', 'SYS_POSTCODE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 4, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (5, 1, '60029b5a-c31f-47f9-b877-fc869142c91a', 'TEXT', 'CITY', 'SYS_CITY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 5, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (8, 1, 'e1e677aa-e9f3-46dc-8d9d-f9ca3164a3c9', 'PHONE', 'MOBILE', 'SYS_MOBILE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 6, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (9, 1, '0ad95dc7-4b4d-428a-990b-617eca65022b', 'DATE', 'BIRTHDAY', 'SYS_BIRTHDAY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 8, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (10, 1, 'ed64785f-afe4-47b6-8ec7-401aea37191b', 'RADIO_BUTTON', 'GENDER', 'SYS_GENDER', NULL, 0, 'fa-mars|SYS_MALE\nfa-venus|SYS_FEMALE\nfa-mars-stroke-v|SYS_DIVERSE', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 9, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (11, 1, 'ea2346a5-e342-4178-979d-c24071fc21cb', 'EMAIL', 'EMAIL', 'SYS_EMAIL', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 1, 2, 10, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (21, 1, 'f9d3387a-f04a-42c0-9431-8fb8003451ad', 'TEXT_BIG', 'ADMIN_REMARK', 'Admin Remark', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 10, 2, '2024-04-03 15:38:22', 2, '2024-04-06 15:09:20');
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (22, 1, 'f9a113e2-f020-4072-abfb-927296cff780', 'TEXT_BIG', 'MEMBER_REMARK', 'Member Remark', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 0, 11, 2, '2024-04-03 15:38:51', 2, '2024-04-06 15:09:04');
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (23, 3, '79129121-d02c-478a-9ad3-a756797e8406', 'DATE', 'EFFECTIVE_DATE', 'Effective Date', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 0, 1, 2, '2024-04-03 16:17:33', 2, '2024-04-06 15:08:47');
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (24, 3, '36f98bb7-6c48-48f3-ab85-6e1dcbcf3163', 'CHECKBOX', 'MEMBER_STATUS', 'Member Status', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 2, 2, '2024-04-03 16:18:15', 2, '2024-04-06 15:08:33');
INSERT INTO `adm2_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (25, 3, '5850a20f-8fa8-495b-af87-e96946cb660b', 'NUMBER', 'GUEST_COUNT', 'Guest Count', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 3, 2, '2024-04-06 15:08:16', NULL, NULL);


# dumping data for admidio.adm2_user_log
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (1, 3, 1, NULL, 'Majumdar', 2, '2024-04-03 14:09:17', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (2, 3, 2, NULL, 'Popy', 2, '2024-04-03 14:09:17', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (4, 3, 10, NULL, '2', 2, '2024-04-03 14:09:17', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (5, 4, 1, NULL, 'Sing', 2, '2024-04-03 14:10:29', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (6, 4, 2, NULL, 'Raunak', 2, '2024-04-03 14:10:29', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (8, 4, 10, NULL, '1', 2, '2024-04-03 14:10:29', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (9, 3, 11, NULL, 'popy.majumdar@gmail.com', 2, '2024-04-06 10:41:27', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (10, 3, 23, NULL, '2024-04-01', 2, '2024-04-06 10:41:27', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (11, 3, 24, NULL, '1', 2, '2024-04-06 10:41:27', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (12, 4, 23, NULL, '2024-04-05', 2, '2024-04-06 10:42:03', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (13, 4, 24, NULL, '1', 2, '2024-04-06 10:42:03', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (14, 4, 11, NULL, 'test@test.com', 2, '2024-04-06 10:42:22', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (15, 2, 24, NULL, '0', 2, '2024-04-06 10:42:33', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (16, 3, 24, '1', '0', 2, '2024-04-06 10:53:29', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (17, 3, 8, NULL, '480-319-5677', 2, '2024-04-06 11:06:07', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (18, 3, 25, NULL, '3', 2, '2024-04-06 15:14:19', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (19, 4, 25, NULL, '2', 2, '2024-04-06 15:14:28', NULL);
INSERT INTO `adm2_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (20, 2, 25, NULL, '2', 2, '2024-04-06 15:14:36', NULL);


# dumping data for admidio.adm2_user_relation_types
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (1, '7ca89a62-ab73-41cf-be3c-98c39bf51edf', 'Parent', 'Father', 'Mother', 0, 2, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (2, 'd7f7dc1a-e178-418b-b432-834e169fe129', 'Child', 'Son', 'Daughter', 0, 1, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (3, '11d6c843-75a1-4e42-a0d5-e4052942d672', 'Sibling', 'Brother', 'Sister', 0, 3, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (4, '205ee10a-6724-4b9a-b3e3-79f1a6a6955c', 'Spouse', 'Husband', 'Wife', 0, 4, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (5, '34d8c6bd-423b-4082-ba80-c045b9c5b6ab', 'Partner', 'Partner', 'Partner', 0, 5, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (6, 'c6252258-debd-4c84-b28c-c9452d2e94b1', 'Friend', 'Friend', 'Girlfriend', 0, 6, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (7, 'd10439a7-422d-4e88-a80a-d920d4ca41ef', 'Boss', 'Boss', 'Female superior', 0, 8, 1, '2024-04-03 13:59:50', NULL, NULL);
INSERT INTO `adm2_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (8, '0112510b-2745-440d-b0b1-d3e8480e86c3', 'Subordinate', 'Male subordinate', 'Female subordinate', 0, 7, 1, '2024-04-03 13:59:50', NULL, NULL);




# dumping data for admidio.adm2_users
INSERT INTO `adm2_users` (`usr_id`, `usr_uuid`, `usr_login_name`, `usr_password`, `usr_photo`, `usr_text`, `usr_pw_reset_id`, `usr_pw_reset_timestamp`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES (1, '7d076e7c-2848-4d14-aa9a-83513674888f', 'System', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, '2024-04-03 13:59:50', NULL, NULL, 0);
INSERT INTO `adm2_users` (`usr_id`, `usr_uuid`, `usr_login_name`, `usr_password`, `usr_photo`, `usr_text`, `usr_pw_reset_id`, `usr_pw_reset_timestamp`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES (2, 'e17dd5d5-b53d-49fa-8c11-890e0e6935d6', 'subhas', '$2y$12$.SSZ76mo9nEAUuNsgc.DBOF6Z0NLE.Tj5ygyJE/BF9O9bUPUOBlnS', NULL, NULL, NULL, NULL, '2024-04-08 16:18:27', '2024-04-10 16:58:18', 37, NULL, 0, 1, '2024-04-03 13:59:50', 2, '2024-04-06 15:14:36', 1);
INSERT INTO `adm2_users` (`usr_id`, `usr_uuid`, `usr_login_name`, `usr_password`, `usr_photo`, `usr_text`, `usr_pw_reset_id`, `usr_pw_reset_timestamp`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES (3, '481b711a-cbe0-4efa-aa4e-f303b085051b', 'majumdar.popy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 2, '2024-04-03 14:09:17', 2, '2024-04-06 15:14:19', 1);
INSERT INTO `adm2_users` (`usr_id`, `usr_uuid`, `usr_login_name`, `usr_password`, `usr_photo`, `usr_text`, `usr_pw_reset_id`, `usr_pw_reset_timestamp`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES (4, '06724be0-6446-4167-b559-47215dd80103', 'sing.raunak', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 2, '2024-04-03 14:10:29', 2, '2024-04-06 15:14:28', 1);


SET FOREIGN_KEY_CHECKS=1;

